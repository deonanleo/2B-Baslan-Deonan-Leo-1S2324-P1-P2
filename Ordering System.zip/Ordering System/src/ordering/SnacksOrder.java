package ordering;

// Order subclass for snacks
class SnacksOrder extends Order {
    SnacksOrder() {
        super("Snacks");
    }

    // Display the snacks menu
    @Override
    void displayMenu() {
        System.out.println("1. Snack1 - ₱ 5.00"
                        +"\n2. Snack2 - ₱ 8.00"
                        +"\n3. Snack3 - ₱ 10.00");
    }

    // Get the snacks menu items
    @Override
    MenuItem[] getMenu() {
        return new MenuItem[]{
                new SnackItem("Snack1", 5.00),
                new SnackItem("Snack2", 8.00),
                new SnackItem("Snack3", 10.00)
        };
    }

    // Process selected items for snacks order
    @Override
    void processSelectedItems(String[] selectedItems) {
        double total = calculateTotal(selectedItems);
        System.out.print("\nName          : "+getFullName());
        System.out.print("\nCourse/Yr/Sec : "+getProgram());
        System.out.println("\nOrder       :\n" + displaySelectedItems(selectedItems));
        System.out.println("Total of      : ₱" + total);
    }
}

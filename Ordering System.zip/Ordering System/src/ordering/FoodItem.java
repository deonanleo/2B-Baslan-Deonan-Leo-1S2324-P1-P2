package ordering;

// Menu item class for foods
class FoodItem implements MenuItem {
    private String name;
    private double price;

    FoodItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    // Get the price of the food
    @Override
    public double getPrice() {
        return price;
    }

    // Get the name of the food
    @Override
    public String getName() {
        return name;
    }
}
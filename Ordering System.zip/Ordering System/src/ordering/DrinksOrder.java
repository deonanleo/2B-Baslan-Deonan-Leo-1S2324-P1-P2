package ordering;

// Order subclass for drinks
class DrinksOrder extends Order {
    DrinksOrder() {
        super("Drinks");
    }
    
    // Display the drinks menu
    @Override
    void displayMenu() {
        System.out.println("1. Water  - ₱ 10.00"
                        +"\n2. Coke   - ₱ 20.00"
                        +"\n3. Yakult - ₱ 12.00");
    }

    // Get the drinks menu items
    @Override
    MenuItem[] getMenu() {
        return new MenuItem[]{
                new DrinkItem("Water", 10.00),
                new DrinkItem("Coke", 20.00),
                new DrinkItem("Yakult", 12.00)
            
        };
    }

    // Process selected items for drinks order
    @Override
    void processSelectedItems(String[] selectedItems) {
        double total = calculateTotal(selectedItems);
        System.out.print("\nName          : "+getFullName());
        System.out.print("\nCourse/Yr/Sec : "+getProgram());
        System.out.println("\nOrder:\n" + displaySelectedItems(selectedItems));
        System.out.println("Total of      : ₱" + total);
    }
}
package ordering;

// Menu item class for desserts
class DessertItem implements MenuItem {
    private String name;
    private double price;

    DessertItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    // Get the price of the dessert
    @Override
    public double getPrice() {
        return price;
    }

    // Get the name of the dessert
    @Override
    public String getName() {
        return name;
    }
}
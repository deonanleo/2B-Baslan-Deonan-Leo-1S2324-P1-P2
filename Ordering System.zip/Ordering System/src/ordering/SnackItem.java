package ordering;

// Menu item class for snacks
class SnackItem implements MenuItem {
    private String name;
    private double price;

    SnackItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    // Get the price of the snack
    @Override
    public double getPrice() {
        return price;
    }

    // Get the name of the snack
    @Override
    public String getName() {
        return name;
    }
}
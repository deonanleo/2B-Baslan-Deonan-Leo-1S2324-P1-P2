package ordering;

// Define an interface for menu items
interface MenuItem {
    double getPrice();
    String getName();
}
package ordering;

// Order subclass for foods
class DishOrder extends Order {
    DishOrder() {
        super("Dishes");
    }

    // Display the foods menu
    @Override
    void displayMenu() {
        System.out.println("1. Dish1 - ₱ 25.00"
                        +"\n2. Dish2 - ₱ 30.00"
                        +"\n3. Dish3 - ₱ 35.00");
    }

    // Get the foods menu items
    @Override
    MenuItem[] getMenu() {
        return new MenuItem[]{
                new DishItem("Dish1", 25.00),
                new DishItem("Dish2", 30.00),
                new DishItem("Dish3", 35.00)
        };
    }

    // Process selected items for foods order
    @Override
    void processSelectedItems(String[] selectedItems) {
        double total = calculateTotal(selectedItems);
        System.out.print("\nName          : "+getFullName());
        System.out.print("\nCourse/Yr/Sec : "+getProgram());
        System.out.println("\nOrder         :\n" + displaySelectedItems(selectedItems));
        System.out.println("Total of      : ₱" + total);
    }
}
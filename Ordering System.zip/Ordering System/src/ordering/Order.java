package ordering;

import java.util.Scanner;
// Abstract class for different types of orders
abstract class Order {
    private String type;
    private String fullName;
    private String program;
    
    // Constructor to set the order type
    Order(String type) {
        this.type = type;
    }
    
    // Getters and setters for fullName
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    // Getters and setters for program
    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }
    
    // Abstract method to display the menu
    abstract void displayMenu();

    // Abstract method to get the menu items
    abstract MenuItem[] getMenu();

    // Method to prompt the user to select items
    void selectItems() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nSelect your order (comma-separated): ");
        String[] selectedItems = scanner.nextLine().split(",");
        processSelectedItems(selectedItems);
    }

    // Abstract method to process selected items
    abstract void processSelectedItems(String[] selectedItems);

    // Check if the item number is valid
    private boolean isValidItemNumber(int itemNumber, int menuLength) {
        return itemNumber >= 1 && itemNumber <= menuLength;
    }
    
    // Calculate the total cost of selected items
    double calculateTotal(String[] selectedItems) {
        double total = 0;
        MenuItem[] menu = getMenu();

        for (String item : selectedItems) {
            int itemNumber = Integer.parseInt(item.trim());

            if (isValidItemNumber(itemNumber, menu.length)) {
                total += menu[itemNumber - 1].getPrice();
            }
        }

        return total;
    }

    // Display the selected items and their prices
    String displaySelectedItems(String[] selectedItems) {
        String result = "";

        for (String item : selectedItems) {
            int itemNumber = Integer.parseInt(item.trim());

            if (isValidItemNumber(itemNumber, getMenu().length)) {
                result += getMenu()[itemNumber - 1].getName() + " - ₱ "
                        + getMenu()[itemNumber - 1].getPrice() + "\n";
            }
        }

        return result.replaceAll(", ₱", ""); // Remove the last comma and space
    }
    

    // Provide a string representation of the order type
    public String toString() {
        return "\nSelect an order for " + type + " Category";
    }
}
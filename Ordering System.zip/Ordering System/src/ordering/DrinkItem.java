package ordering;

// Menu item class for drinks
class DrinkItem implements MenuItem {
    private String name;
    private double price;
    
    DrinkItem(String name, double price) {
        this.name = name;
        this.price = price;
    }

    // Get the price of the drink
    @Override
    public double getPrice() {
        return price;
    }

    // Get the name of the drink
    @Override
    public String getName() {
        return name;
    }
    
}
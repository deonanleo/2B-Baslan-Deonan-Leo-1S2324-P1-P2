package ordering;

// Order subclass for desserts
class DessertsOrder extends Order {
    DessertsOrder() {
        super("Desserts");
    }

    // Display the desserts menu
    @Override
    void displayMenu() {
        System.out.println("1. Dessert1 - ₱ 15.00"
                        +"\n2. Dessert2 - ₱ 18.00"
                        +"\n3. Dessert3 - ₱ 20.00");
    }

    // Get the desserts menu items
    @Override
    MenuItem[] getMenu() {
        return new MenuItem[]{
                new DessertItem("Dessert1", 15.00),
                new DessertItem("Dessert2", 18.00),
                new DessertItem("Dessert3", 20.00)
        };
    }

    // Process selected items for desserts order
    @Override
    void processSelectedItems(String[] selectedItems) {
        double total = calculateTotal(selectedItems);
        System.out.print("\nName          : "+getFullName());
        System.out.print("\nCourse/Yr/Sec : "+getProgram());
        System.out.println("\nOrder       :\n" + displaySelectedItems(selectedItems));
        System.out.println("Total of      : ₱" + total);
    }
}

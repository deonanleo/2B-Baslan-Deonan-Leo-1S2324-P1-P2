package ordering;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Display welcome messages
            System.out.println("\t\tC T U  D A A N B A N T A Y A N\n");
            System.out.println("\t\t O R D E R I N G  S Y S T E M\n");

            // Ask user if they want to order
            System.out.print("Hi! Would you like to order? [Y or N]: ");
            String orderChoice = scanner.next().toUpperCase();

            // Exit if user doesn't want to order
            if (!orderChoice.equals("Y")) {
                System.out.println("Thank you for using the ordering system. Have a nice day!");
                return;
            }

            // Consume the newline character
            System.out.print("\n");
            scanner.nextLine();

            // Get user details
            System.out.print("Enter your Name (Full Name): ");
            String fullName = scanner.nextLine();

            System.out.print("Enter Course/Yr/Sec: ");
            String program = scanner.nextLine();

            // Continue ordering until user decides to stop
            while (orderChoice.equals("Y")) {
                displayCategories();
                System.out.print("Select what you'd like to order: ");
                int categoryChoice = scanner.nextInt();

                // Get the selected order category
                Order selectedOrder = getOrderForCategory(categoryChoice);

                // Process the selected order
                if (selectedOrder != null) {
                    selectedOrder.setFullName(fullName);
                    selectedOrder.setProgram(program);
                    processOrder(scanner, selectedOrder);
                } else {
                    System.out.println("Invalid category choice.");
                }

                // Ask if the user wants to order more
                System.out.print("\nWould you like to order more? [Y or N]: ");
                orderChoice = scanner.next().toUpperCase();
            }

            // Display a thank you message
            System.out.println("\nThank you " + fullName + " for ordering. Please wait; your order will be prepared. Have a nice day!");
        } catch (Exception e) {
            System.out.println("An unexpected error occurred. Please try again.");
        }
    }

    // Display available categories
    private static void displayCategories() {
        System.out.println("\nC A T E G O R I E S\n\n1. Drinks\n2. Snacks\n3. Desserts\n4. Foods\n5. Dishes\n");
    }

    // Get the order based on the selected category
    private static Order getOrderForCategory(int categoryChoice) {
        switch (categoryChoice) {
            case 1:
                return new DrinksOrder();
            case 2:
                return new SnacksOrder();
            case 3:
                return new DessertsOrder();
            case 4:
                return new FoodsOrder();
            case 5:
                return new DishOrder();
            default:
                return null;
        }
    }

    // Process the order details
    private static void processOrder(Scanner scanner, Order selectedOrder) {
        System.out.println("\nHi " + selectedOrder.getFullName() + ".");
        System.out.println(selectedOrder);
        selectedOrder.displayMenu();
        selectedOrder.selectItems();

        // Ask if the user wants to place the order
        System.out.print("\nType Y (Yes) to place your order: ");
        String place = scanner.next().toUpperCase();

        // Exit if the user decides not to place the order
        if (!place.equals("Y")) {
            System.out.println("Exiting the program. Make sure to order all you want before placing your order.");
            System.exit(0);
        }
    }
}
